# Knowledge TEMP → 正式K映射

207条原件保持不变。一个TEMP拆出的多个K按具体内容取用；合并只合命题，不合主体与获取时点。空壳退役不是删除审计历史。

|原ID与标题|正式去向|处理与理由|
|---|---|---|
|[K_TEMP_001](TEMP_INDEX.md#k_temp_001) 白玫＝林小璐|[K001](K001.md)|CONVERTED：新闻可见不等人人看出日常身份。|
|[K_TEMP_002](TEMP_INDEX.md#k_temp_002) 救援地点|[K002](K002.md)|CONVERTED：匿名电话只给地点与危险提示；来电真实主体当时未知。|
|[K_TEMP_003](TEMP_INDEX.md#k_temp_003) 翠雀代号及花牌|[K003](K003.md)、[K191](K191.md)|SPLIT：另拆花牌号码，不能由报号得男身。|
|[K_TEMP_004](TEMP_INDEX.md#k_temp_004) 摩可来历任命|[K004](K004.md)|CONVERTED：确认自述发生；履历独立可靠性当时只有D，后接登记回复。|
|[K_TEMP_005](TEMP_INDEX.md#k_temp_005) 翠雀与白玫魔法少女身份|[K005](K005.md)、[K192](K192.md)|SPLIT：另拆白玫身份；不含林昀。|
|[K_TEMP_006](TEMP_INDEX.md#k_temp_006) 蛹巢假说|[K006](K006.md)|CONVERTED：先是林的调查假说并告红，后林亲探；不自动把后验证同步红。|
|[K_TEMP_007](TEMP_INDEX.md#k_temp_007) 夏凉离家出走|[K007](K007.md)|CONVERTED：说出的离家情况不等完整家史。|
|[K_TEMP_008](TEMP_INDEX.md#k_temp_008) 小璐对葬礼拥抱的理解|[K008](K008.md)|CONVERTED：小璐的解释有误；当时是安慰与警告传递，夏只听小的版本。|
|[K_TEMP_009](TEMP_INDEX.md#k_temp_009) 调查涉深与警告|[K009](K009.md)|CONVERTED：属官自称来自猫眼，不能直接认定每层原话与动机。|
|[K_TEMP_010](TEMP_INDEX.md#k_temp_010) 荼蘼已牺牲|[K010](K010.md)|CONVERTED：死亡与林后来获讯分开。|
|[K_TEMP_011](TEMP_INDEX.md#k_temp_011) 下水道蛹巢|[K006](K006.md)|MERGED：亲探补证同一蛹巢命题；保留红只获假说的阶段。|
|[K_TEMP_012](TEMP_INDEX.md#k_temp_012) 摩可登记|[K011](K011.md)|CONVERTED：外市播种者转交，非完整履历证明。|
|[K_TEMP_013](TEMP_INDEX.md#k_temp_013) 爪痕关联樱之死|[K012](K012.md)|CONVERTED：摩丝提供线索和猜测；全书没有可据此锁定全部幕后链的证据。|
|[K_TEMP_014](TEMP_INDEX.md#k_temp_014) 夏凉父母结局|[K013](K013.md)|CONVERTED：当代翠从夏自述及回忆得家史，儿童自责与母亲动机另判。|
|[K_TEMP_015](TEMP_INDEX.md#k_temp_015) 夏凉完整家史|[K013](K013.md)|MERGED：记录小璐未获完整家史，不重复建立同一家庭命题。|
|[K_TEMP_016](TEMP_INDEX.md#k_temp_016) 红思与退役字牌身份|[K014](K014.md)|CONVERTED：仅该历史阶段；后续复力不取消当时退役事实。|
|[K_TEMP_017](TEMP_INDEX.md#k_temp_017) 花级与花牌关系|[K015](K015.md)|CONVERTED：摩可的混淆由红解释纠正；制度细节不因该句全掌握。|
|[K_TEMP_018](TEMP_INDEX.md#k_temp_018) 父亲当日出行目的|[K016](K016.md)|CONVERTED：跟踪者原误会被共同选礼纠正，不顺带揭其他秘密。|
|[K_TEMP_019](TEMP_INDEX.md#k_temp_019) 父亲知道白玫身份|[K017](K017.md)|CONVERTED：EV0019只构成暴露线索；明确解释获知时间在EV0020 L4299–4311。|
|[K_TEMP_020](TEMP_INDEX.md#k_temp_020) 林昀＝翠雀|[K018](K018.md)|CONVERTED：单独于矢/翠/龙少女代号链、性别来源和女王身世；夏确知同一性仍误会来源。|
|[K_TEMP_021](TEMP_INDEX.md#k_temp_021) 安雅与翠雀旧队联系|[K019](K019.md)、[K193](K193.md)|SPLIT：合照只支持旧交，不包含男身。|
|[K_TEMP_022](TEMP_INDEX.md#k_temp_022) 安雅魔法少女身份|[K020](K020.md)|CONVERTED：终身资格与其称号不推出全知或无敌。|
|[K_TEMP_023](TEMP_INDEX.md#k_temp_023) 安雅遗体消散|[K021](K021.md)|CONVERTED：林未在场，后辈转述给林；不向所有队员授予尸体现象细节。|
|[K_TEMP_024](TEMP_INDEX.md#k_temp_024) 夏凉晋芽及初期镜面功能|[K022](K022.md)、[K194](K194.md)|SPLIT：另拆引离已观察功能，不预载后期穿墙。|
|[K_TEMP_025](TEMP_INDEX.md#k_temp_025) 摩可与变身承诺|[K023](K023.md)、[K195](K195.md)|SPLIT：许诺发生可确证；另拆复眼可行性，不能把许诺当疗效。|
|[K_TEMP_026](TEMP_INDEX.md#k_temp_026) 黑袍追索目标是自己|[K024](K024.md)|CONVERTED：她先偷听左眼线索推知，不是由摩可首次告知才知道。|
|[K_TEMP_027](TEMP_INDEX.md#k_temp_027) 白静萱是追索目标及新魔法少女|[K025](K025.md)、[K196](K196.md)|SPLIT：田当面见变身；记忆后遗缺口另接，不假定永久完整记得。|
|[K_TEMP_028](TEMP_INDEX.md#k_temp_028) 自身疗伤效果|[K026](K026.md)|CONVERTED：观察的个案，不等知道病因或能复所有伤。|
|[K_TEMP_029](TEMP_INDEX.md#k_temp_029) 翠雀代号及工触十一死讯|[K027](K027.md)、[K197](K197.md)|SPLIT：兵触三由小璐称呼获知；不是知道矢或林；另拆工触十一死讯。|
|[K_TEMP_030](TEMP_INDEX.md#k_temp_030) 蓝色少女是矢车菊|[K028](K028.md)|CONVERTED：麻雀通过监视试探旧照比对；原文明确没分享，不给摩丝自动同步。|
|[K_TEMP_031](TEMP_INDEX.md#k_temp_031) 新人可能遇险|[K029](K029.md)|CONVERTED：翠当时仅按失联定位与敌言推测；不能读取并行战况。|
|[K_TEMP_032](TEMP_INDEX.md#k_temp_032) 林昀与矢车菊关系|[K030](K030.md)、[K198](K198.md)|SPLIT：只赋王有限关联；另拆“男身是女孩伪装”的错误方向。|
|[K_TEMP_033](TEMP_INDEX.md#k_temp_033) 新人合战成果|[K031](K031.md)|CONVERTED：翠获事后战报，不亲见所有白魔细节；敌死亡另有截击过程。|
|[K_TEMP_034](TEMP_INDEX.md#k_temp_034) 樱曾救白静萱|[K032](K032.md)|CONVERTED：白原知救援者；林到EV0032才获知这次交集。|
|[K_TEMP_035](TEMP_INDEX.md#k_temp_035) 翠雀＝矢车菊|[K033](K033.md)|CONVERTED：刘辨认、小璐拼接、陆蓝线验证分别建节点，非同步揭晓。|
|[K_TEMP_036](TEMP_INDEX.md#k_temp_036) 樱去向|[K034](K034.md)|CONVERTED：翠的隐瞒让白误解；后蛾战死讯修正，另有安死亡真命题。|
|[K_TEMP_037](TEMP_INDEX.md#k_temp_037) 樱案黑烬线索|[K035](K035.md)|CONVERTED：确认猫眼通报的线索，不将其升为全案定论；红被请离。|
|[K_TEMP_038](TEMP_INDEX.md#k_temp_038) 薄雪对自身旧伤疗效|[K036](K036.md)|CONVERTED：EV0035暗试无可感改善，仅本次/当期能力，非永世无法治疗。|
|[K_TEMP_039](TEMP_INDEX.md#k_temp_039) 旧队成员与加入顺序|[K037](K037.md)|CONVERTED：给读者的旧队回忆不等夏已听全；夏口述范围另绑当代EV0039。|
|[K_TEMP_040](TEMP_INDEX.md#k_temp_040) 翠雀对出游的关系定义|[K038](K038.md)|CONVERTED：承诺/表态本身可证，不等恋爱确立或知道夏全部内心。|
|[K_TEMP_041](TEMP_INDEX.md#k_temp_041) 翠雀旧代号矢车菊|[K033](K033.md)|MERGED：夏凉在咖啡店阶段获旧名；与其他主体分人分时合并。|
|[K_TEMP_042](TEMP_INDEX.md#k_temp_042) 林昀原本男性|[K039](K039.md)|CONVERTED：夏的推理方向错误且EV0110未完成纠正；不等否定女王所述身体来源仍待核。|
|[K_TEMP_043](TEMP_INDEX.md#k_temp_043) 猫尾小队失踪|[K040](K040.md)|CONVERTED：历史失联阶段；后来获救返国，不能留成末态失踪。|
|[K_TEMP_044](TEMP_INDEX.md#k_temp_044) 翠雀暂离安排|[K041](K041.md)|CONVERTED：本人明确安排，只传播公开行程和课程。|
|[K_TEMP_045](TEMP_INDEX.md#k_temp_045) 翠雀与矢车菊旧号关联|[K042](K042.md)|CONVERTED：读牌现象不等理解承继或男身；不与完整035认同自动合并。|
|[K_TEMP_046](TEMP_INDEX.md#k_temp_046) 巷中遇险经过|[K043](K043.md)|CONVERTED：实际是木误伤自己；没目击解变，不能以救援印象自动纠正同一性。|
|[K_TEMP_047](TEMP_INDEX.md#k_temp_047) 猫尾转查黑烬及失踪规模|[K044](K044.md)|CONVERTED：猫尾→灯→翠的任务线索；22为转述估数，不是普遍统计真值。|
|[K_TEMP_048](TEMP_INDEX.md#k_temp_048) 黑烬烬军烬卫烬侍层级|[K045](K045.md)|CONVERTED：确认蛛说过这些分类；具体制度与全部地区组织图仍只到口供D。|
|[K_TEMP_049](TEMP_INDEX.md#k_temp_049) 蛛网覆盖区域的缠绕条件|[K046](K046.md)|CONVERTED：翠提出解释并令灯破网成功；只支持本次操作，不给全原理。|
|[K_TEMP_050](TEMP_INDEX.md#k_temp_050) 其他城市异常|[K047](K047.md)|CONVERTED：猫尾报告及调查成果，尚非翠亲访四城。|
|[K_TEMP_051](TEMP_INDEX.md#k_temp_051) 薄雪天音觉醒|[K048](K048.md)|CONVERTED：出差时女孩们未告翠，后实际见到不再UNAWARE；不前置四韵律。|
|[K_TEMP_052](TEMP_INDEX.md#k_temp_052) 林昀男身|[K049](K049.md)|CONVERTED：认识这张脸不等知道他是翠雀。|
|[K_TEMP_053](TEMP_INDEX.md#k_temp_053) 当晚警告|[K050](K050.md)|CONVERTED：林→红私下转述，不证明局员全知或警告已上报。|
|[K_TEMP_054](TEMP_INDEX.md#k_temp_054) 局员及柏安办公室兽来源|[K051](K051.md)|CONVERTED：物品、行为和不还击先支持推理，后实际救回印证；不等全局所有人如此。|
|[K_TEMP_055](TEMP_INDEX.md#k_temp_055) 红受控且不能说幕后名字|[K052](K052.md)|CONVERTED：行为征象→受控回忆揭示；禁想遗忘须另保留知识下降。|
|[K_TEMP_056](TEMP_INDEX.md#k_temp_056) 林昀安雅恋爱订婚|[K053](K053.md)|CONVERTED：红由安主动宣布获知，不是当天已经结婚。|
|[K_TEMP_057](TEMP_INDEX.md#k_temp_057) 红被摩丝暗算|[K054](K054.md)|CONVERTED：回忆给读者；不能给当时未听全述的翠一份完整囚禁经历。|
|[K_TEMP_058](TEMP_INDEX.md#k_temp_058) 电话接收者为巡查使|[K055](K055.md)|CONVERTED：红只告诉妮妮巡查使，不等告诉男身真名。|
|[K_TEMP_059](TEMP_INDEX.md#k_temp_059) 匿名警告来源链|[K056](K056.md)|CONVERTED：读者后来知道来源；林当时仅接到匿名片段，不自动获手机来历。|
|[K_TEMP_060](TEMP_INDEX.md#k_temp_060) 自己能够获救|[K057](K057.md)|CONVERTED：她原以为无救，醒后亲见感官恢复；不证明所有同类均可救。|
|[K_TEMP_061](TEMP_INDEX.md#k_temp_061) 摩丝＝蛾|[K058](K058.md)|CONVERTED：敌公开自报给现场三新人；不等方亭公众全部知晓。|
|[K_TEMP_062](TEMP_INDEX.md#k_temp_062) 樱已死及小璐为其女儿|[K059](K059.md)|CONVERTED：拆死讯与母女关系分别跟踪；白受刺激昏迷，后续敌话不再自动听到。|
|[K_TEMP_063](TEMP_INDEX.md#k_temp_063) 摩丝改造技术|[K060](K060.md)|CONVERTED：口供说明与救援现象部分相印；人物女儿经历/控诉不一并A。|
|[K_TEMP_064](TEMP_INDEX.md#k_temp_064) 阴影覆盖夺魔条件|[K061](K061.md)|CONVERTED：翠试线、敌补盖支持实战规则；精确全机制仍不授予。|
|[K_TEMP_065](TEMP_INDEX.md#k_temp_065) 缝合者可以分离兽部分救回|[K062](K062.md)|CONVERTED：分离实证推翻此前无救判断；剪损和建筑未复原保留。|
|[K_TEMP_066](TEMP_INDEX.md#k_temp_066) 翠雀与白玫父亲关联|[K063](K063.md)|CONVERTED：摩丝临死私语才领会，不将此提前到双祭子报告。|
|[K_TEMP_067](TEMP_INDEX.md#k_temp_067) 翠雀在方亭相关踪迹|[K064](K064.md)|CONVERTED：木描外观和名字→玛辨认，确认踪迹不等知当下行程。|
|[K_TEMP_068](TEMP_INDEX.md#k_temp_068) 疑似携樱宝石小队全灭|[K065](K065.md)|CONVERTED：猫眼报告本身带“疑似”；宝石是否在该队及真凶不可强定。|
|[K_TEMP_069](TEMP_INDEX.md#k_temp_069) 新局长为林昀|[K066](K066.md)|CONVERTED：田办公室见→小父亲承认→木被捕会面；职务公开不等全城实知。|
|[K_TEMP_070](TEMP_INDEX.md#k_temp_070) 六暗子及武装方案|[K067](K067.md)、[K199](K199.md)|SPLIT：限本场证实六人，不等再无暗子；武装计划另拆。|
|[K_TEMP_071](TEMP_INDEX.md#k_temp_071) 兽之源名称及修复方案|[K068](K068.md)|CONVERTED：方案存在A、可行性解释D；当时尚未手术，另接实际结果。|
|[K_TEMP_072](TEMP_INDEX.md#k_temp_072) 林昀翠雀将婚及收养|[K069](K069.md)|CONVERTED：白误拼婚姻与照护，林翠同一；法律收养从未确认，夏打趣不是误信。|
|[K_TEMP_073](TEMP_INDEX.md#k_temp_073) 白狼与紫钻、兽之源分流|[K070](K070.md)、[K200](K200.md)|SPLIT：祖早期口述D，后叙述补证；兽源分流另拆。|
|[K_TEMP_074](TEMP_INDEX.md#k_temp_074) 湖畔春天与袭局双线陷阱|[K071](K071.md)|CONVERTED：林根据通联搜查推理贯通，不直接获敌方全部预案。|
|[K_TEMP_075](TEMP_INDEX.md#k_temp_075) 自身兽子与父母来历|[K072](K072.md)、[K201](K201.md)|SPLIT：明确记录说法发生；出身细节、父母恶意和白害亲不能一起确认。|
|[K_TEMP_076](TEMP_INDEX.md#k_temp_076) 翠雀愿做妈妈|[K073](K073.md)|CONVERTED：现场和归途承诺，后夏获告；不等法律收养或身份揭露。|
|[K_TEMP_077](TEMP_INDEX.md#k_temp_077) 小璐为曙草付费原因|[K074](K074.md)|CONVERTED：女孩承认与叙述支持；648误点不等消费习惯普遍结论。|
|[K_TEMP_078](TEMP_INDEX.md#k_temp_078) 索白与矢的额外任务|[K075](K075.md)|CONVERTED：鸢→塞米只转任务范围，不代表已执行或获目标全身世。|
|[K_TEMP_079](TEMP_INDEX.md#k_temp_079) 鸢旧职与爪痕身份|[K076](K076.md)|CONVERTED：查档及本人回应；不能由蓝线识矢反向推出陆知男身。|
|[K_TEMP_080](TEMP_INDEX.md#k_temp_080) 朝颜恢复力量及繁开|[K077](K077.md)、[K202](K202.md)|SPLIT：红救援可见；繁开解释只私给翠，另建命题。|
|[K_TEMP_081](TEMP_INDEX.md#k_temp_081) 气与百武物理化|[K078](K078.md)|CONVERTED：翠听鸢解释并剪去该作用，不能推純武術已独立超凡。|
|[K_TEMP_082](TEMP_INDEX.md#k_temp_082) 退役魔力可恢复与红身体治疗方案|[K079](K079.md)、[K203](K203.md)|SPLIT：方案→治疗后复职证据；不是当时已完成制造。|
|[K_TEMP_083](TEMP_INDEX.md#k_temp_083) 小璐商城目击|[K080](K080.md)|CONVERTED：是当面转述，未发警告短信不是传播证据。|
|[K_TEMP_084](TEMP_INDEX.md#k_temp_084) 林昀现任局长|[K066](K066.md)|MERGED：同一职务增加小璐获知节点，不重复设命题。|
|[K_TEMP_085](TEMP_INDEX.md#k_temp_085) 翠雀可能喜欢安雅|[K081](K081.md)|CONVERTED：小的单因猜测，不等客观全部动机，且不揭父女同一性。|
|[K_TEMP_086](TEMP_INDEX.md#k_temp_086) 翠雀已向白承诺当妈妈|[K073](K073.md)|MERGED：夏在EV0078听翠解释母称承诺，不给她早期全知。|
|[K_TEMP_087](TEMP_INDEX.md#k_temp_087) 林昀愿作父亲式照护者|[K082](K082.md)|CONVERTED：情感称呼许可，法律关系F；与翠雀妈妈认知分别存。|
|[K_TEMP_088](TEMP_INDEX.md#k_temp_088) 2月14并非登记生日|[K083](K083.md)|CONVERTED：童年捡巧克力故事为自述D；查簿与选择纪念日不可混成真实生日。|
|[K_TEMP_089](TEMP_INDEX.md#k_temp_089) 陌生支援者可能旧识|[K084](K084.md)|CONVERTED：当时猜旧识，尚未認玛本人；援助者实际木百合。|
|[K_TEMP_090](TEMP_INDEX.md#k_temp_090) 彼此真身与魔法身份|[K085](K085.md)|CONVERTED：与林战后互解变身；林的反向身份并入020，各自披露分列。|
|[K_TEMP_091](TEMP_INDEX.md#k_temp_091) 歌手＝玛格丽特|[K086](K086.md)|CONVERTED：林眼眸确认当代重逢；历史曾知其真名不等演出前认出此人。|
|[K_TEMP_092](TEMP_INDEX.md#k_temp_092) 翠与歌手旧识|[K087](K087.md)|CONVERTED：散场翠告夏/白，不使歌迷知旧队与男性身份。|
|[K_TEMP_093](TEMP_INDEX.md#k_temp_093) 玛对安雅死讯获知及未赴葬礼缘由|[K088](K088.md)|CONVERTED：获讯是两年前；EV0083是向林解释，绝非玛此刻首次听死讯。|
|[K_TEMP_094](TEMP_INDEX.md#k_temp_094) 私比冲突|[K089](K089.md)|CONVERTED：翠经白蓟楼梯道歉、玛解释后来获悉，不是亲见完整私比。|
|[K_TEMP_095](TEMP_INDEX.md#k_temp_095) 考核风险与队内限制变化|[K090](K090.md)|CONVERTED：两次公布时间分别保留；不是国度统一资格制度。|
|[K_TEMP_096](TEMP_INDEX.md#k_temp_096) 翠借假考生入国度治疗|[K091](K091.md)|CONVERTED：红较早知，玛60私谈得知；三新人只有另一个有限任务口径。|
|[K_TEMP_097](TEMP_INDEX.md#k_temp_097) 苏胜紫退役赴间界线索|[K092](K092.md)|CONVERTED：苏→玛历史通话→林红当代转述；到达/存亡/阵营仍F。|
|[K_TEMP_098](TEMP_INDEX.md#k_temp_098) 翠失控与魔丝打结|[K093](K093.md)|CONVERTED：红玛看见现象不等知道侵蚀原因或命运预言。|
|[K_TEMP_099](TEMP_INDEX.md#k_temp_099) 屏障与爆术组合思路|[K094](K094.md)|CONVERTED：教学理论→首次实作耗竭；不能预授蛹级必杀成效。|
|[K_TEMP_100](TEMP_INDEX.md#k_temp_100) 浊化为模拟偏移且底色不变|[K095](K095.md)|CONVERTED：世界层定性与玛讲解D区分；翠先见表现再听解释。|
|[K_TEMP_101](TEMP_INDEX.md#k_temp_101) 小璐主动白魔及性质|[K096](K096.md)|CONVERTED：两导师看清，仍未确认祭子根源；不等吸空白蓟魔力。|
|[K_TEMP_102](TEMP_INDEX.md#k_temp_102) 兽之源归祖母绿|[K097](K097.md)|CONVERTED：交付EV0164证实客观；鸢未核实→白狼暂按真，后借回是新的物态。|
|[K_TEMP_103](TEMP_INDEX.md#k_temp_103) 父亲与翠雀恋爱|[K098](K098.md)|CONVERTED：小一度采用的错误解释→跨年前自己不再相信；未由此识同一人。|
|[K_TEMP_104](TEMP_INDEX.md#k_temp_104) 白称林爸爸|[K099](K099.md)|CONVERTED：熟人听称呼私传，不是公开法律领养公告。|
|[K_TEMP_105](TEMP_INDEX.md#k_temp_105) 林小璐是局长女儿且魔法少女|[K100](K100.md)、[K204](K204.md)|SPLIT：陆当面获父女关联；另接变身白玫，不自动识翠与父同一。|
|[K_TEMP_106](TEMP_INDEX.md#k_temp_106) 装置破防吸兽威胁|[K101](K101.md)|CONVERTED：装置存在，完整破网波动时限来自鸢威胁，拆除后未照单实施验证。|
|[K_TEMP_107](TEMP_INDEX.md#k_temp_107) 鸢变换是心解非繁开|[K102](K102.md)|CONVERTED：玛初误认，经敌纠正只达局部理解；不含完整心解原理。|
|[K_TEMP_108](TEMP_INDEX.md#k_temp_108) 白黑绿兽形|[K103](K103.md)|CONVERTED：其他同伴此时亲见；不等祭子完整定义、父母秘密。|
|[K_TEMP_109](TEMP_INDEX.md#k_temp_109) 白是要求带走对象|[K104](K104.md)|CONVERTED：鸢按兽形辨目标，不授予父母及林真身。|
|[K_TEMP_110](TEMP_INDEX.md#k_temp_110) 翠杯底比例意义|[K105](K105.md)|CONVERTED：红误将不同容量比例比较；翠纠正，贯胸真实伤势不被取消。|
|[K_TEMP_111](TEMP_INDEX.md#k_temp_111) 塞米为间界妖精及兽形|[K106](K106.md)、[K205](K205.md)|SPLIT：四追击新人听本人自述；另拆兽形，不自动知和墨过去。|
|[K_TEMP_112](TEMP_INDEX.md#k_temp_112) 巢内睁闭眼互感规律|[K107](K107.md)|CONVERTED：含羞与小逐次试验、广播，保留推理层，不推广所有巢。|
|[K_TEMP_113](TEMP_INDEX.md#k_temp_113) 石塔为辅助装置|[K108](K108.md)|CONVERTED：夏白蓟二查所获，仅该装置。|
|[K_TEMP_114](TEMP_INDEX.md#k_temp_114) 翠是否只视自己为樱替影|[K109](K109.md)|CONVERTED：小的怀疑遭翠明确否认；亲生关系和实际照护另有证据。|
|[K_TEMP_115](TEMP_INDEX.md#k_temp_115) 白静萱祭子判定|[K110](K110.md)|CONVERTED：玛听翠说且不懂定义，后薄荷只提供部分释义。|
|[K_TEMP_116](TEMP_INDEX.md#k_temp_116) 龙胆伪装工具能力边界|[K111](K111.md)|CONVERTED：祖交付/说明，衣装覆盖另阶段，不授予真实第二本相。|
|[K_TEMP_117](TEMP_INDEX.md#k_temp_117) 白祭子及湖畔兽形经历|[K110](K110.md)|MERGED：小后获白部分交代，夏已先私问；父母与血腥战记仍隐瞒。|
|[K_TEMP_118](TEMP_INDEX.md#k_temp_118) 林昀局长身份|[K066](K066.md)|MERGED：木被捕会面才知林局长，不知男翠同一。|
|[K_TEMP_119](TEMP_INDEX.md#k_temp_119) 旧记录是否登王之门|[K112](K112.md)|CONVERTED：林根据旧文猜测，无法认定具体对象。|
|[K_TEMP_120](TEMP_INDEX.md#k_temp_120) 王钥可能孵化新形态|[K113](K113.md)|CONVERTED：翠当时猜测，不把后期命题理论倒填当时已掌握。|
|[K_TEMP_121](TEMP_INDEX.md#k_temp_121) 木父母与琴行收养经历|[K114](K114.md)|CONVERTED：玛向翠转述家史；木仍信寄养，父亲具体后续F。|
|[K_TEMP_122](TEMP_INDEX.md#k_temp_122) 父亲会回来|[K115](K115.md)|CONVERTED：木相信寄养承诺，文本未给回归结果；不能改成客观必不回来。|
|[K_TEMP_123](TEMP_INDEX.md#k_temp_123) 兽源已转卢恩诺雷|[K116](K116.md)|CONVERTED：白狼自称线人核实，限听见餐桌成员；实际转运细节不得补齐。|
|[K_TEMP_124](TEMP_INDEX.md#k_temp_124) 翠隐藏身份执行秘密任务|[K117](K117.md)|CONVERTED：任务口径确有说明，治疗政治全貌未披露。|
|[K_TEMP_125](TEMP_INDEX.md#k_temp_125) 龙胆十岁登记身份|[K118](K118.md)|CONVERTED：土读伪证形成认识；后揭伪装，不改变登记伪证真实存在。|
|[K_TEMP_126](TEMP_INDEX.md#k_temp_126) 爱之源与修宝石用途|[K119](K119.md)|CONVERTED：操作实证与朋友来源自述D分开；未使旧毁武装回归。|
|[K_TEMP_127](TEMP_INDEX.md#k_temp_127) 妮娜姐妹参战动机|[K120](K120.md)|CONVERTED：矢询问才明白部分处境；只限同队与照护安排。|
|[K_TEMP_128](TEMP_INDEX.md#k_temp_128) 术后恢复与再献祭风险|[K121](K121.md)、[K206](K206.md)|SPLIT：另拆再献祭风险；保留静养限制和本相损失。|
|[K_TEMP_129](TEMP_INDEX.md#k_temp_129) 面具少女＝妮娜墨荷|[K122](K122.md)|CONVERTED：林由见脸和旧识确认，不同于黑猫代号确认。|
|[K_TEMP_130](TEMP_INDEX.md#k_temp_130) 墨荷现任务与义肢来源|[K123](K123.md)、[K207](K207.md)|SPLIT：翠听说但存疑；后爪痕联系不等确认任务说辞合法。|
|[K_TEMP_131](TEMP_INDEX.md#k_temp_131) 林昀纪念生日2月14|[K124](K124.md)|CONVERTED：林→白→小，夏稍后得计划；不同于真实生日或女身身份确认。|
|[K_TEMP_132](TEMP_INDEX.md#k_temp_132) 墨荷与爪痕关联|[K125](K125.md)|CONVERTED：沉默时仅怀疑→郁叛逃与同活动合证确认；不等黑猫代号。|
|[K_TEMP_133](TEMP_INDEX.md#k_temp_133) 墨团队知三次昙开及修复承诺|[K126](K126.md)、[K208](K208.md)|SPLIT：墨的承诺与翠听到不证明可行性，另拆知道三次昙开。|
|[K_TEMP_134](TEMP_INDEX.md#k_temp_134) 翠因往事落泪|[K127](K127.md)|CONVERTED：小只获简说“往事”，不获得读者可见完整回忆。|
|[K_TEMP_135](TEMP_INDEX.md#k_temp_135) 郁金香在墨荷身边|[K128](K128.md)|CONVERTED：翠认其旧名，金蛇号尚未得知。|
|[K_TEMP_136](TEMP_INDEX.md#k_temp_136) 林昀与翠雀同一人|[K018](K018.md)|MERGED：小白对同生日只有巧合解释，不算获同一身份。|
|[K_TEMP_137](TEMP_INDEX.md#k_temp_137) 队长是否讨厌自己|[K129](K129.md)|CONVERTED：妮娜先误会，历史战后互谈释疑；不倒填初见信任。|
|[K_TEMP_138](TEMP_INDEX.md#k_temp_138) 墨荷团队与爪痕联系|[K125](K125.md)|MERGED：从怀疑到关联确认，保留当代时间阈值。|
|[K_TEMP_139](TEMP_INDEX.md#k_temp_139) 郁金香现号金蛇|[K130](K130.md)|CONVERTED：祖线人推认告诉翠，个体获讯强度只PARTIAL；读者确认不自动加强其确信。|
|[K_TEMP_140](TEMP_INDEX.md#k_temp_140) 矢车菊已返国|[K131](K131.md)|CONVERTED：祖仅先告本席，宴会本人出现；不可扩展整个国度。|
|[K_TEMP_141](TEMP_INDEX.md#k_temp_141) 翠拟成为魔事权杖|[K132](K132.md)|CONVERTED：翠告三新人并要求保密；意向不是正式任命。|
|[K_TEMP_142](TEMP_INDEX.md#k_temp_142) 折鹤兰有女儿|[K133](K133.md)|CONVERTED：拿错箱后临编，职员传播；不证明折是否另有真实子女。|
|[K_TEMP_143](TEMP_INDEX.md#k_temp_143) 混乱术扰考|[K134](K134.md)|CONVERTED：当届相关人员获公告；使用者动机与全部源头未知。|
|[K_TEMP_144](TEMP_INDEX.md#k_temp_144) 自觉失常不等未努力|[K135](K135.md)|CONVERTED：复问与干扰查证纠正自责，不等所有错题皆外因。|
|[K_TEMP_145](TEMP_INDEX.md#k_temp_145) 龙胆作为动画风格新人前辈|[K136](K136.md)|CONVERTED：狗根据互动形成有限假身份印象；后自报代号纠正。|
|[K_TEMP_146](TEMP_INDEX.md#k_temp_146) 谜奖励及专属捷径|[K137](K137.md)|CONVERTED：广播此时才生效可知；不提前给规则五。|
|[K_TEMP_147](TEMP_INDEX.md#k_temp_147) 引离可影响迷宫墙|[K138](K138.md)|CONVERTED：观察植物结构可移，不泛化所有实体墙与直接传人。|
|[K_TEMP_148](TEMP_INDEX.md#k_temp_148) 节点全破才出出口|[K139](K139.md)|CONVERTED：后有特殊出口提前公告，旧规则知情与例外分开。|
|[K_TEMP_149](TEMP_INDEX.md#k_temp_149) 猫姐就是墨荷|[K140](K140.md)|CONVERTED：旁白201章确认；翠不在密谈，不能接读者记录。|
|[K_TEMP_150](TEMP_INDEX.md#k_temp_150) 墨荷＝黑猫|[K140](K140.md)|MERGED：保留翠缺席此轮揭露的边界，不新立同命题。|
|[K_TEMP_151](TEMP_INDEX.md#k_temp_151) 测绘队出口候选|[K141](K141.md)|CONVERTED：夏以醉的能力情报换地图，候选非出口已证；并未交出穿墙秘密。|
|[K_TEMP_152](TEMP_INDEX.md#k_temp_152) 小锦穿墙能力|[K138](K138.md)|MERGED：公开展示用途是后阶段传播，不能回溯成为开场常识。|
|[K_TEMP_153](TEMP_INDEX.md#k_temp_153) 薄荷箭根薯疑涉黑烬|[K142](K142.md)|CONVERTED：小白先闻兽味→报翠，翠此时只是推测；薄后自承才升级特定部分。|
|[K_TEMP_154](TEMP_INDEX.md#k_temp_154) 祭子食祭兽子定义|[K143](K143.md)|CONVERTED：确认她作出解释；词义只限她提供的范围，食祭唯一生还结局另见未证命题。|
|[K_TEMP_155](TEMP_INDEX.md#k_temp_155) 箭醉羊蛇及薄名单|[K144](K144.md)|CONVERTED：供述发生A，名单成员事实各自待证，不扩大完整黑烬名册。|
|[K_TEMP_156](TEMP_INDEX.md#k_temp_156) 白静萱有偏移|[K145](K145.md)|CONVERTED：考官只有检测偏移，不等知道兽底色和家庭起源。|
|[K_TEMP_157](TEMP_INDEX.md#k_temp_157) 王钥有权杖潜力|[K146](K146.md)、[K209](K209.md)|SPLIT：检测和评估支持潜力，不等必获权杖；内部S+与公开SS另条。|
|[K_TEMP_158](TEMP_INDEX.md#k_temp_158) 白玫SS评级|[K147](K147.md)|CONVERTED：EV0133公布才公开；之前内部报告S+，不能互换。|
|[K_TEMP_159](TEMP_INDEX.md#k_temp_159) 女王已通过渠道关注小璐|[K148](K148.md)|CONVERTED：翠获转达，不等知道女王全部目的。|
|[K_TEMP_160](TEMP_INDEX.md#k_temp_160) 小王钥可能不圆满|[K149](K149.md)|CONVERTED：木棉直觉与战败线索触发翠判断；不是“木芙蓉”已证诊断。|
|[K_TEMP_161](TEMP_INDEX.md#k_temp_161) 小璐母亲是樱|[K150](K150.md)|CONVERTED：新紫钻由小亲告纠正身份猜测；不等知男性父亲是翠。|
|[K_TEMP_162](TEMP_INDEX.md#k_temp_162) 紫对小培养条件|[K151](K151.md)|CONVERTED：小向翠事后转述，翠不在室内；不当女王亲口全套条件。|
|[K_TEMP_163](TEMP_INDEX.md#k_temp_163) 血蝠夺取魔力|[K152](K152.md)|CONVERTED：小亲历后才可回解首场干瘪；不是当时就知道吸的是什么。|
|[K_TEMP_164](TEMP_INDEX.md#k_temp_164) 王钥基础回魔限制|[K153](K153.md)|CONVERTED：不可通过随收随放无限回满；小在云境才明确实际限制。|
|[K_TEMP_165](TEMP_INDEX.md#k_temp_165) 龙胆是矢车菊女儿|[K154](K154.md)|CONVERTED：小编谎不误信；土狗接收错误，EV0149纠正少女链。|
|[K_TEMP_166](TEMP_INDEX.md#k_temp_166) 龙胆带任务且考核有内幕|[K155](K155.md)|CONVERTED：翠仅向土狗掌书提示，未分享敌名单或男身。|
|[K_TEMP_167](TEMP_INDEX.md#k_temp_167) 箭雾态与施符条件|[K156](K156.md)|CONVERTED：小的旧推断被融雾身体实际施符推翻，现象不等完整雾化机制。|
|[K_TEMP_168](TEMP_INDEX.md#k_temp_168) 夏追逐中处境|[K157](K157.md)|CONVERTED：翠感知与事后结果，未知风镜陷阱预案。|
|[K_TEMP_169](TEMP_INDEX.md#k_temp_169) 黑猫另有任务|[K158](K158.md)|CONVERTED：金蛇从措辞起疑，不知道刺王目标。|
|[K_TEMP_170](TEMP_INDEX.md#k_temp_170) 郁金香灾难预感|[K159](K159.md)|CONVERTED：预感存在不证明预知能力；矢未将其落实成正式预警。|
|[K_TEMP_171](TEMP_INDEX.md#k_temp_171) 早期半蜕可能试演|[K160](K160.md)|CONVERTED：矢墨从兽形相似推测，不能把推测变确定幕后部署。|
|[K_TEMP_172](TEMP_INDEX.md#k_temp_172) 妮姆当时安全|[K161](K161.md)|CONVERTED：严格当时安全，后死亡使当前信息过时。|
|[K_TEMP_173](TEMP_INDEX.md#k_temp_173) 敌有第二羽与自报蜂使徒|[K162](K162.md)、[K210](K210.md)|SPLIT：亲见现象；另拆历史蜂自报及同一性未决。|
|[K_TEMP_174](TEMP_INDEX.md#k_temp_174) 石蒜昙开具体现场|[K163](K163.md)|CONVERTED：两人无现场观察权限；后来遗言死讯不自动赋唱名细节。|
|[K_TEMP_175](TEMP_INDEX.md#k_temp_175) 救矢的规避办法|[K164](K164.md)|CONVERTED：猜测行为为A，方案内容可行性C/D，未告诉矢完整推理。|
|[K_TEMP_176](TEMP_INDEX.md#k_temp_176) 握今争取时间|[K165](K165.md)|CONVERTED：矢体验暂停，不自动知道墨的另一救法和全部代价。|
|[K_TEMP_177](TEMP_INDEX.md#k_temp_177) 处理伤员者效忠国度|[K166](K166.md)|CONVERTED：亲见自述A，不能把一度怀疑升级伤员全死；幸存者后有疗养证据。|
|[K_TEMP_178](TEMP_INDEX.md#k_temp_178) 妮姆死亡与墨断臂|[K167](K167.md)、[K211](K211.md)|SPLIT：林探望获死讯；墨已有丧妹知识，当年安全不能沿用。|
|[K_TEMP_179](TEMP_INDEX.md#k_temp_179) 妮姆踏明与护民行动|[K168](K168.md)|CONVERTED：林列车读取认证牌记忆才获，死亡听闻与行动细节分开。|
|[K_TEMP_180](TEMP_INDEX.md#k_temp_180) 龙胆＝翠雀＝矢车菊|[K169](K169.md)|CONVERTED：土狗于末场前亲见揭伪；矢旧名另连035，不含男身。|
|[K_TEMP_181](TEMP_INDEX.md#k_temp_181) 褐鹈原木槿身份|[K170](K170.md)|CONVERTED：收押现场核对，不公开给考生。|
|[K_TEMP_182](TEMP_INDEX.md#k_temp_182) 金蛇交易对抗状态|[K171](K171.md)|CONVERTED：不能命名通用时间循环或全知重置；观察保留与解释分开。|
|[K_TEMP_183](TEMP_INDEX.md#k_temp_183) 姐妹与食祭关系|[K172](K172.md)|CONVERTED：现场听到仅局部，童年收留/半年受训/分离回忆不自动给小白。|
|[K_TEMP_184](TEMP_INDEX.md#k_temp_184) 白狼名妃黛莉|[K173](K173.md)|CONVERTED：原读者条目不造NPC普遍知情；现场称名另核发言收听者。|
|[K_TEMP_185](TEMP_INDEX.md#k_temp_185) 考核暂停|[K174](K174.md)|CONVERTED：外场公告不是食祭结界内已获救或能听到。|
|[K_TEMP_186](TEMP_INDEX.md#k_temp_186) 女王与翠雀亲子宣称|[K185](K185.md)|MERGED：与188同一黑猫获亲子宣称记录，EV0155绑定过早，改接EV0157，不新增传播。|
|[K_TEMP_187](TEMP_INDEX.md#k_temp_187) 袭击目标可能女王|[K175](K175.md)|CONVERTED：白推测，羊自述偷听；四人只听到有限说法，女王已死为另个假说。|
|[K_TEMP_188](TEMP_INDEX.md#k_temp_188) 女王亲子说法|[K185](K185.md)|MERGED：黑猫在EV0157听亲子宣称；内容D，不能以听到认完整创造机制。|
|[K_TEMP_189](TEMP_INDEX.md#k_temp_189) 改兽底色替代方案|[K176](K176.md)|CONVERTED：黑猫的替代提议未普适验证，翠不接受以此保障所有人。|
|[K_TEMP_190](TEMP_INDEX.md#k_temp_190) 恨今难握时间错位解释|[K177](K177.md)|CONVERTED：翠战中测试局部支持的解释，不写已掌完整原理。|
|[K_TEMP_191](TEMP_INDEX.md#k_temp_191) 幻命织华完整效果与胜负|[K178](K178.md)|CONVERTED：正文止于唱名，没有效果结局；严禁补胜负。|
|[K_TEMP_192](TEMP_INDEX.md#k_temp_192) 新任魔法少女活动|[K179](K179.md)|CONVERTED：林通勤看见陌生蓝色少女，非当场认白玫且未看完整战果。|
|[K_TEMP_193](TEMP_INDEX.md#k_temp_193) 林昀与花园防卫战关联|[K180](K180.md)|CONVERTED：红经外市→播种者回复、苏旧述、林部分承认拼出；不是完整宫中往事。|
|[K_TEMP_194](TEMP_INDEX.md#k_temp_194) 浊化操作|[K181](K181.md)|CONVERTED：三天学习证据，翠当时尚未知技术，不以同队自动同步。|
|[K_TEMP_195](TEMP_INDEX.md#k_temp_195) 妮妮返国及任职手续|[K182](K182.md)|CONVERTED：厨房对话实际是妮妮→翠雀；准备当天动身，不等已到国度或摩可已收到任职文件。|
|[K_TEMP_196](TEMP_INDEX.md#k_temp_196) 福利院主动救人经历|[K183](K183.md)|CONVERTED：后来只记躲藏受救，改用MEMORY_LOSS并记录错误片段；施术者及精确清忆时刻F。|
|[K_TEMP_197](TEMP_INDEX.md#k_temp_197) 白静萱偏移方向|[K184](K184.md)|CONVERTED：祖初判反向→检查修正；解释内容D，现象/后文支持与知情强度分列。|
|[K_TEMP_198](TEMP_INDEX.md#k_temp_198) 女王提出的亲子与身世说法|[K185](K185.md)、[K212](K212.md)、[K213](K213.md)|SPLIT：林历史听闻先激动信母后疑惧，黑猫当代才听；不裁成生物学定论。|
|[K_TEMP_199](TEMP_INDEX.md#k_temp_199) 女王对战争与力量依存的解释|[K186](K186.md)|CONVERTED：女王解释与翠用以护驾的风险判断；不可写所有少女已知或必然失能。|
|[K_TEMP_200](TEMP_INDEX.md#k_temp_200) 姐妹互杀处境与亲情|[K172](K172.md)|MERGED：增加小在阻止自伤时听到的姐妹牵挂，不把“都知道”扩展整段回忆。|
|[K_TEMP_201](TEMP_INDEX.md#k_temp_201) 安雅死亡|[K187](K187.md)|CONVERTED：客观死讯与林/玛/白不同获知时间分列。|
|[K_TEMP_202](TEMP_INDEX.md#k_temp_202) 白静萱准备返校|[K188](K188.md)|CONVERTED：小旅途补习支持部分知情；不补已注册或具体学校。|
|[K_TEMP_203](TEMP_INDEX.md#k_temp_203) 苏胜紫去间界的最后通话消息|[K092](K092.md)|EMPTY_SHELL_RETIRED：空壳TEMP没有主体行；保留映射与废弃空壳说明，信息由205/204承接。|
|[K_TEMP_204](TEMP_INDEX.md#k_temp_204) 苏胜紫最后通话的间界去向|[K092](K092.md)|MERGED：同EV0086重复转述，归并但保留映射。|
|[K_TEMP_205](TEMP_INDEX.md#k_temp_205) 苏胜紫准备去间界|[K092](K092.md)|MERGED：历史玛听苏本人和当代转述分开，真实去向不升级。|
|[K_TEMP_206](TEMP_INDEX.md#k_temp_206) 当晚残兽可能有危险|[K189](K189.md)|CONVERTED：初次断续警告没有地点，回拨002才补地点；来电者身份仍匿名。|
|[K_TEMP_207](TEMP_INDEX.md#k_temp_207) 林昀能与心之种连接|[K190](K190.md)|CONVERTED：兔形妖精由否定转目击白光确认；安雅远处作战不能自动算亲见。|


## Stage 2C有效状态

当前为192 EV、70 CH、172 REL（583阶段）、235 K（365获取节点）。历史TEMP原文及阶段Review保存原口径，当前调用以records.json、正式档案及[Stage 2C修订队列](../STAGE2C_REVIEW_QUEUE.md)为准。早期构建脚本及其输入仅供追溯，不可直接重跑覆盖当前库。CR021将K017父早知与渠道解释分为EV0019/EV0020；CR008/009/018将错挂的历史与当代关系、知情分开。
