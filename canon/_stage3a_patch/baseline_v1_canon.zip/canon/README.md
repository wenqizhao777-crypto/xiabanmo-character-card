# Canon Reference｜CANON_BASELINE_V1

**Stage 2C：完成。CANON_BASELINE_V1 = FROZEN**

本基线将原著事实、人物状态、有向关系和人物知情范围分开；同一人物必须按剧情节点读取。冻结只固定可追溯事实与边界，不消除未知，不代表已经制作角色卡或通过RP宿主验收。

|当前模块|稳定范围与数量|入口|
|---|---|---|
|来源规则|原著最高，A–F分级、事实/认知/推断分层|[Source Policy](00_source_policy.md)|
|事件|EV0001–EV0192，192；原189不重编号|[时间线](01_master_timeline.md)|
|世界层|WR001–014、PS001–038、ORG001–019、LOC001–036，共107|[世界](02_world_rules.md) / [力量](03_power_system.md) / [组织](04_organizations.md) / [地点](05_locations.md)|
|人物|CH001–CH070；A10/B26/C32/D2；原38快照；99条未知/争议索引|[人物](characters/README.md)|
|有向关系|REL001–REL172；583阶段、36家庭分层、1436未知维度|[关系](relationships/README.md)|
|知识|K001–K235；365获取节点、20披露边、207旧TEMP全部接续|[认知](knowledge/README.md)|
|回归|60组三层联合情境＋原38快照；55项实际查询|[快照](SNAPSHOT_REGRESSION.md) / [查询](CANON_QUERY_TESTS.md)|

先读[基线清单](BASELINE_MANIFEST.md)、[最终Review](STAGE2C_FINAL_REVIEW.md)、[核证队列](STAGE2C_REVIEW_QUEUE.md)及[变更日志](CHANGELOG_STAGE2C.md)。原Stage Review、TEMP_INDEX及旧_build*目录是历史资料，不覆盖当前记录，不能直接重跑旧整理脚本。70主体记录不等于已证明70个互异自然人；CH044/CH069同一性仍未定。

## 下游读取顺序与边界

1. [来源规则](00_source_policy.md)和[用户决定](../audit/USER_DECISIONS.md)：原著决定Canon事实，用户明确决定允许如何改编；两者来源必须可区分。
2. [Manifest](BASELINE_MANIFEST.md)、[未解导航](UNRESOLVED.md)、[推断限制](INFERENCE_GUARDRAILS.md)、[后续待议设计](USER_DECISIONS_PENDING_STAGE2C.md)。本轮无新增阻塞裁决；原5组设计细则仍留后续。
3. 选Event与前/后位置，再读对应世界层、人物阶段和两个方向的关系；不能套全书末态。
4. 按主体查[Knowledge](knowledge/README.md)及[只读查询](knowledge/query_knowledge.py)，核对获取时点与来源。群体知道不等个人知道，别名同一不等人物已识破。事件中段及不可比较历史节点须核源段。
5. 未来经授权才做心理/语言/行为建模与RP执行描述。不能改事实、提升推断等级、移除认知壁垒或改原著关系。新事实证据须正式变更日志，不能就地无记录覆盖Baseline。

现有未知范围：WQ40、CQ8、RQ7导航；人物99条；关系1436未知维度；K33项重要未知。它们层级不同、有交叉，不相加冒充独立问题总数。

Stage 1全文阅读仍为100%，1,641,637字符。Stage 2C做整合核证与回归，未重新声称全文逐字阅读。source/current/audit及final均未写入。本任务完成后停止，未进入Claude人物建模、世界书重构、角色卡制作或游戏系统设计。
